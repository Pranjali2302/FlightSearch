My personal React boilerplate. You can learn more about it [here](https://sebhastian.com/react-configuration-tutorial)

To use it, run `npm install` then `npm run start`

For production build, run `npm run build`