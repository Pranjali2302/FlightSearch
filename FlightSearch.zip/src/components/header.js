import React from 'react';
const Header = (props) => {
    return (
        <>
            <div className="bg-gray-400 p-4">
                <h1 className="text-center text-black font-bold text-2xl">Flight Booking</h1>
            </div>

        </>
    );
};

export default Header;
